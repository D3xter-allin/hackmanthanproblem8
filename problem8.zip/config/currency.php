<?php

return [
    'currencies_with_right_symbols' => [
        '﷼',
        '₨',
        '₪',
        '₨',
        'Ft',
        'TL',
        'ман',
        'лв',
        '₮',
        'lei',
        'zł',
        'руб',
        // add new currencies symbols needed to be on the right side

    ],
    'needs_code_with_symbol' => [
        'AUD',
        // add new currencies codes needed to be with the symbol
    ],
];
