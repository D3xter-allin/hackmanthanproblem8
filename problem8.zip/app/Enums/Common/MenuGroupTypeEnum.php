<?php

namespace App\Enums\Common;

enum MenuGroupTypeEnum: string
{
    case admin = 'admin';

    case mega = 'mega';
}
