<?php

namespace App\Http\Controllers;

class FavouriteController extends Controller
{
    //
}
