<?php

namespace App\Domains\Marketplace\Contracts;

interface UninstallExtensionServiceProviderInterface
{
    public static function uninstall(): void;
}
