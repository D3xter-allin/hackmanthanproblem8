<?php

namespace App\Helpers\Classes;

class ApiHelper
{
    use Traits\HasApiKeys;
}
